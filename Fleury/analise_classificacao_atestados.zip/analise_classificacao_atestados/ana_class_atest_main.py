# -*- coding: utf-8 -*-

from flow.ana_class_atest_flows import fluxo1

if __name__ == "__main__":

    fluxo1()
