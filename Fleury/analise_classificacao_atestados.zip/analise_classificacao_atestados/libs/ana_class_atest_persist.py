# -*- coding: utf-8 -*-

import sqlite3

